package com.esame.directors;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DirectorsApplicationTests {

	@Test
	void contextLoads() {
	}

}
