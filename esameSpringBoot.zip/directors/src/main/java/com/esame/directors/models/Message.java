package com.esame.directors.models;

public class Message {
    private Integer message;


    public Message() {
    }
    public Message(Integer message) {
        this.message = message;
    }
    public Integer getMessage() {
        return message;
    }
    public void setMessage(Integer message) {
        this.message = message;
    }
    
}
