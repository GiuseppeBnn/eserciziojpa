package com.esame.directors.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Directors {
    @Id
    @GeneratedValue
    private Long id;
    
    private String name;
    private String surname;
    private Integer age;
    private String year;
    

    public Directors() {
    }
    public Directors(Long id, String name, String surname, String year, Integer age) {
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.year = year;
        this.age = age;
        
    }

    public Integer getAge() {
        return age;
    }
    public void setAge(Integer age) {
        this.age = age;
    }
    public Long getId(){
        return this.id;

    }
    public void setId(Long id){
        this.id = id;

    }
    public String getName(){
        return this.name;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getSurname(){
        return this.surname;
    }
    public void setSurname(String surname){
        this.surname = surname;
    }
    public String getYear(){
        return this.year;
    }
    public void setYear(String year){
        this.year = year;
    }

}
