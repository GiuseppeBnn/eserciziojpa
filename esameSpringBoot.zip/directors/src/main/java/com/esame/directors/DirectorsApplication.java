package com.esame.directors;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DirectorsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DirectorsApplication.class, args);
	}

}
