package com.esame.directors.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.ui.Model;
import com.esame.directors.data.DirectorsRepository;
import com.esame.directors.models.Directors;
import org.springframework.web.bind.annotation.PathVariable;
import java.util.List;
import com.esame.directors.models.Message;

@Controller
@RequestMapping("/directors")
public class DirectorsController {
    private DirectorsRepository directorsRepository;
    public DirectorsController(DirectorsRepository directorsRepository){
        this.directorsRepository = directorsRepository;
    }
    @GetMapping
    public String getDirectors(Model model){
        model.addAttribute("directors", directorsRepository.findAll());
        model.addAttribute("message", new Message());
        return "directors.list";
    }
    @GetMapping("/new")
    public String newDirectors(Model model){
        model.addAttribute("directors", new Directors());
        return "directors.new";
    }
    @PostMapping("/store")
    public String storeDirectors(@ModelAttribute Directors directors){
        directors.setAge(2023-Integer.parseInt(directors.getYear()));
        this.directorsRepository.save(directors);
        return "redirect:/directors";
    }
    @GetMapping(path="/{id}")
    public String showDirectors(@PathVariable Long id, Model model){
        model.addAttribute("directors", this.directorsRepository.getReferenceById(id));
        return "directors.show";
    }
    @PostMapping(path="/olderThen")
    public String showDirectorsOlderThen(@ModelAttribute Message age, Model model){
        List<Directors> directors=this.directorsRepository.findByAgeGreaterThanEqual(age.getMessage());
        
        
        model.addAttribute("directors", directors);
        model.addAttribute("age", age);
        return "directors.olderThen";
    }
    
}
