package com.esame.directors.data;

import org.springframework.data.jpa.repository.JpaRepository;
import com.esame.directors.models.Directors;
import java.util.List;
public interface DirectorsRepository extends JpaRepository<Directors, Long>{
    List<Directors> findByAgeGreaterThanEqual(Integer age);
}
